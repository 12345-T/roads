package ru.ispu.roads;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
class Login {
    public String Log(String logBox, String passBox) {
        String Log, Pass, toast ="";
        String[][] cursor = new String [][]{{"Admin", "1234"},{"Guest", "123"}, {"Administrator", "12345"}};
        boolean checker = false;
        for (int i = 0; i < cursor.length; i++){
            Log = cursor[i][0];
            Pass = cursor[i][1];
            if (logBox.equals(Log) & passBox.equals(Pass)) {
                checker = true;
                break;
            }
        }
        if (checker) {
            toast = "Вы авторизовались.";
        }
        else
        {
            toast = "Неправильный логин или пароль.";
        }
        return toast;
    }
}

public class ExampleUnitTest {
    @Test
    public void Test1() {
        Login L = new Login();
        assertEquals("Вы авторизовались.", L.Log("Admin", "1234"));
    }
    @Test
    public void Test2() {
        Login L = new Login();
        assertEquals("Неправильный логин или пароль.", L.Log("Admin", "123"));
    }
    @Test
    public void Test3() {
        Login L = new Login();
        assertEquals("Неправильный логин или пароль.", L.Log("Administrator", "1234"));
    }
}