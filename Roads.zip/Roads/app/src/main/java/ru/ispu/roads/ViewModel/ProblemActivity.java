package ru.ispu.roads.ViewModel;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import ru.ispu.roads.Model.Problem;
import ru.ispu.roads.Model.ProblemUser;
import ru.ispu.roads.Model.User;
import ru.ispu.roads.R;


public class ProblemActivity extends AppCompatActivity {

    TextView nameBox;
    TextView adressBox;
    TextView categoryBox;
    TextView descriptionBox;
    TextView markBox;
    TextView usersBox;
    TextView authorBox;
    Button markButton;
    Button delButton;

    Problem problem;
    SQLiteDatabase db;
    Cursor problemCursor;
    long problemId=0;
    int newMark = 0;
    double AvMark = 0;
    int NumUsers = 0;
    String UserLogin = "";
    String UserRole = "";
    User user;
    SQLiteDatabase db2;
    Cursor userCursor;
    boolean check = false;
    String checkId = "";
    long checkUserId = 0;
    ProblemUser problemUser;
    Cursor problemUserCursor;

    boolean flag1 = true;
    boolean flag2 = true;
    boolean flag3 = true;
    boolean flag4 = true;
    boolean flag5 = true;
    Button btn_star1;
    Button btn_star2;
    Button btn_star3;
    Button btn_star4;
    Button btn_star5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_problem);

        nameBox = (TextView) findViewById(R.id.name);
        adressBox = (TextView) findViewById(R.id.adress);
        categoryBox = (TextView) findViewById(R.id.category);
        descriptionBox = (TextView) findViewById(R.id.description);
        markBox = (TextView) findViewById(R.id.mark);
        usersBox = (TextView) findViewById(R.id.users);
        authorBox = (TextView) findViewById(R.id.author);
        markButton = (Button) findViewById(R.id.markButton);
        btn_star1 = (Button) findViewById(R.id.btn_star1);
        btn_star2 = (Button) findViewById(R.id.btn_star2);
        btn_star3 = (Button) findViewById(R.id.btn_star3);
        btn_star4 = (Button) findViewById(R.id.btn_star4);
        btn_star5 = (Button) findViewById(R.id.btn_star5);

        problem = new Problem(this);
        db = problem.getWritableDatabase();

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            problemId = extras.getLong("id");
            if (extras.getString("login") != null) {
                UserLogin = extras.getString("login");
                UserRole = extras.getString("role");
            }
        }
        // если 0, то добавление
        if (problemId > 0) {
            // получаем элемент по id из бд
            check = false;
            problemCursor = db.rawQuery("select * from " + Problem.TABLE_NAME + " where " +
                    Problem.KEY_ID + "=?", new String[]{String.valueOf(problemId)});
            problemCursor.moveToFirst();
            nameBox.setText(problemCursor.getString(1));
            adressBox.setText(problemCursor.getString(2));
            categoryBox.setText(problemCursor.getString(3));
            descriptionBox.setText(problemCursor.getString(4));
            markBox.setText(problemCursor.getString(5));
            usersBox.setText(problemCursor.getString(6));
            if (problemCursor.getString(7).equals("0")) {
                checkId = problemCursor.getString(7);
                authorBox.setText("Неизвестен");
            }
            else
            {
                check = true;
                checkId = problemCursor.getString(7);
            }
            problemCursor.close();
        }
        if (check) {
            db.close();
            user = new User(this);
            db2 = user.getReadableDatabase();
            userCursor = db2.rawQuery("select * from " + User.TABLE_NAME + " where " +
                    User.KEY_ID + "=?", new String[]{checkId});
            userCursor.moveToFirst();
            authorBox.setText(userCursor.getString(1));
            userCursor.close();
            db2.close();
            db = problem.getWritableDatabase();
        }

        if (UserLogin == "")
        {
            delButton = (Button) findViewById(R.id.deleteButton);
            markButton = (Button) findViewById(R.id.markButton);
            delButton.setVisibility(View.INVISIBLE);
            delButton.setVisibility(View.GONE);
            markButton.setVisibility(View.INVISIBLE);
            markButton.setVisibility(View.GONE);
        }
        else {
            if (UserRole.equals("Пользователь")) {
                delButton = (Button) findViewById(R.id.deleteButton);
                delButton.setVisibility(View.INVISIBLE);
                delButton.setVisibility(View.GONE);
            }
            db.close();
            User user2 = new User(this);
            db2 = user2.getReadableDatabase();
            userCursor = db2.rawQuery("select * from " + User.TABLE_NAME + " where " +
                    User.KEY_LOGIN + "=?", new String[]{UserLogin});
            userCursor.moveToFirst();
            checkUserId = userCursor.getLong(0);
            userCursor.close();
            db2.close();
            problemUser = new ProblemUser(this);
            db = problemUser.getReadableDatabase();
            problemUserCursor = db.rawQuery("select * from " + ProblemUser.TABLE_NAME + " where " +
                    ProblemUser.KEY_PROBLEM_ID + "=?" + " and " + ProblemUser.KEY_USER_ID + "=?", new String[]{String.valueOf(problemId), String.valueOf(checkUserId)});
            problemUserCursor.moveToFirst();
            if (problemUserCursor.getCount() != 0)
            {
                newMark = Integer.parseInt(problemUserCursor.getString(3));
                starCheck ();
            }
            db.close();
            db = problem.getWritableDatabase();
        }
    }

    public void mark(View view) {
        db.close();
        user = new User(this);
        db2 = user.getReadableDatabase();
        userCursor = db2.rawQuery("select * from " + User.TABLE_NAME + " where " +
                User.KEY_LOGIN + "=?", new String[]{UserLogin});
        userCursor.moveToFirst();
        checkUserId = userCursor.getLong(0);
        userCursor.close();
        db2.close();
        int check;
        boolean check2 = false;
        long problemUserId = 0;
        problemUser = new ProblemUser(this);
        db = problemUser.getReadableDatabase();
        problemUserCursor = db.rawQuery("select * from " + ProblemUser.TABLE_NAME + " where " +
                ProblemUser.KEY_PROBLEM_ID + "=?"+ " AND " + ProblemUser.KEY_USER_ID + "=?", new String[]{String.valueOf(problemId), String.valueOf(checkUserId)});
        check = problemUserCursor.getCount();
        if (check > 0)
        {
            problemUserCursor.moveToFirst();
            check2 = !problemUserCursor.getString(3).equals(newMark + "");
            problemUserId = problemUserCursor.getLong(0);
        }
        if (check == 0 | check2) {
            if (check == 0) {
                NumUsers = Integer.parseInt(usersBox.getText().toString()) + 1;
                AvMark = newMark + Double.parseDouble(markBox.getText().toString()) * (NumUsers - 1);
                AvMark = AvMark / NumUsers;
            } else {
                if (check2) {
                    NumUsers = Integer.parseInt(usersBox.getText().toString());
                    AvMark = newMark + Double.parseDouble(markBox.getText().toString()) * NumUsers - Integer.parseInt(problemUserCursor.getString(3));
                    AvMark = AvMark / NumUsers;
                }
            }
            problemUserCursor.close();
            db.close();
            db = problem.getWritableDatabase();
            ContentValues cv = new ContentValues();
            cv.put(Problem.KEY_NAME, nameBox.getText().toString());
            cv.put(Problem.KEY_ADRESS, adressBox.getText().toString());
            cv.put(Problem.KEY_CATEGORY, categoryBox.getText().toString());
            cv.put(Problem.KEY_DESCRIPTION, descriptionBox.getText().toString());
            cv.put(Problem.KEY_AVERAGE_MARK, AvMark + "");
            cv.put(Problem.KEY_NUMBER_OF_RATED_USERS, NumUsers + "");
            cv.put(Problem.KEY_USER_ID, checkId);

            if (problemId > 0) {
                db.update(Problem.TABLE_NAME, cv, Problem.KEY_ID + "=" + String.valueOf(problemId), null);
            } else {
                db.insert(Problem.TABLE_NAME, null, cv);
            }
            db.close();
            db = problemUser.getWritableDatabase();
            ContentValues cv2 = new ContentValues();
            cv2.put(ProblemUser.KEY_PROBLEM_ID, problemId + "");
            cv2.put(ProblemUser.KEY_USER_ID, checkUserId + "");
            cv2.put(ProblemUser.KEY_MARK, newMark + "");
            if (check > 0) {
                db.update(ProblemUser.TABLE_NAME, cv2, ProblemUser.KEY_ID + "=" + String.valueOf(problemUserId), null);
            } else {
                db.insert(ProblemUser.TABLE_NAME, null, cv2);
            }

            goHome();
        }
        else
        {
            Toast toast = Toast.makeText(this, "Изменений не произошло", Toast.LENGTH_LONG);
            toast.show();
        }

    }

    public void delete(View view){
        db.delete(Problem.TABLE_NAME, "_id = ?", new String[]{String.valueOf(problemId)});
        db.close();
        boolean check = false;
        long[] delId;
        problemUser = new ProblemUser(this);
        db = problemUser.getReadableDatabase();
        problemUserCursor = db.rawQuery("select * from " + ProblemUser.TABLE_NAME + " where " +
                ProblemUser.KEY_PROBLEM_ID + "=?", new String[]{String.valueOf(problemId)});
        if (problemUserCursor.getCount() > 0) {
            problemUserCursor.moveToFirst();
            check = true;
            delId = new long[problemUserCursor.getCount()];
            for (int i = 0; i < problemUserCursor.getCount(); i++) {
                delId[i] = problemUserCursor.getLong(0);
                if (i != problemUserCursor.getCount()-1) {
                    problemUserCursor.moveToNext();
                }
            }
        }
        else
        {
            delId = new long[0];
        }
        problemUserCursor.close();
        db.close();
        if(check) {
            db = problemUser.getWritableDatabase();
            for (int i = 0; i<delId.length; i++) {
                db.delete(ProblemUser.TABLE_NAME, "_id = ?", new String[]{String.valueOf(delId[i])});
            }
            db.close();
        }
        goHome();
    }

    private void goHome(){
        // закрываем подключение
        db.close();
        // переход к главной activity
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
    }
    public void starCheck()
    {
        switch (newMark) {
            case 1:
                btn_star1.setBackgroundColor(Color.parseColor("#FFFF80"));
                flag1 = false;
                break;
            case 2:
                btn_star1.setBackgroundColor(Color.parseColor("#FFFF80"));
                btn_star2.setBackgroundColor(Color.parseColor("#FFFF80"));
                flag2 = false;
                break;
            case 3:
                btn_star1.setBackgroundColor(Color.parseColor("#FFFF80"));
                btn_star2.setBackgroundColor(Color.parseColor("#FFFF80"));
                btn_star3.setBackgroundColor(Color.parseColor("#FFFF80"));
                flag3 = false;
                break;
            case 4:
                btn_star1.setBackgroundColor(Color.parseColor("#FFFF80"));
                btn_star2.setBackgroundColor(Color.parseColor("#FFFF80"));
                btn_star3.setBackgroundColor(Color.parseColor("#FFFF80"));
                btn_star4.setBackgroundColor(Color.parseColor("#FFFF80"));
                flag4 = false;
                break;
            case 5:
                btn_star1.setBackgroundColor(Color.parseColor("#FFFF80"));
                btn_star2.setBackgroundColor(Color.parseColor("#FFFF80"));
                btn_star3.setBackgroundColor(Color.parseColor("#FFFF80"));
                btn_star4.setBackgroundColor(Color.parseColor("#FFFF80"));
                btn_star5.setBackgroundColor(Color.parseColor("#FFFF80"));
                flag5 = false;
                break;
        }
    }


    public void S1(View view) {
            if (flag1) {
                btn_star1.setBackgroundColor(Color.parseColor("#FFFF80"));
                btn_star2.setBackgroundColor(Color.parseColor("#DCDCDC"));
                btn_star3.setBackgroundColor(Color.parseColor("#DCDCDC"));
                btn_star4.setBackgroundColor(Color.parseColor("#DCDCDC"));
                btn_star5.setBackgroundColor(Color.parseColor("#DCDCDC"));
                newMark = 1;
                flag1 = false;
                flag2 = true;
                flag3 = true;
                flag4 = true;
                flag5 = true;
            } else {
                btn_star1.setBackgroundColor(Color.parseColor("#DCDCDC"));
                newMark = 0;
                flag1 = true;
            }

    }
    public void S2(View view) {
        if (flag2) {
            btn_star1.setBackgroundColor(Color.parseColor("#FFFF80"));
            btn_star2.setBackgroundColor(Color.parseColor("#FFFF80"));
            btn_star3.setBackgroundColor(Color.parseColor("#DCDCDC"));
            btn_star4.setBackgroundColor(Color.parseColor("#DCDCDC"));
            btn_star5.setBackgroundColor(Color.parseColor("#DCDCDC"));
            newMark = 2;
            flag1 = true;
            flag2 = false;
            flag3 = true;
            flag4 = true;
            flag5 = true;
        } else {
            btn_star1.setBackgroundColor(Color.parseColor("#DCDCDC"));
            btn_star2.setBackgroundColor(Color.parseColor("#DCDCDC"));
            newMark = 0;
            flag2 = true;
        }

    }
    public void S3(View view) {

        if (flag3) {
            btn_star1.setBackgroundColor(Color.parseColor("#FFFF80"));
            btn_star2.setBackgroundColor(Color.parseColor("#FFFF80"));
            btn_star3.setBackgroundColor(Color.parseColor("#FFFF80"));
            btn_star4.setBackgroundColor(Color.parseColor("#DCDCDC"));;
            btn_star5.setBackgroundColor(Color.parseColor("#DCDCDC"));
            newMark = 3;
            flag1 = true;
            flag2 = true;
            flag3 = false;
            flag4 = true;
            flag5 = true;
        } else {
            btn_star1.setBackgroundColor(Color.parseColor("#DCDCDC"));
            btn_star2.setBackgroundColor(Color.parseColor("#DCDCDC"));
            btn_star3.setBackgroundColor(Color.parseColor("#DCDCDC"));
            newMark = 0;
            flag3 = true;
        }

    }
    public void S4(View view) {
        if (flag4) {
            btn_star1.setBackgroundColor(Color.parseColor("#FFFF80"));
            btn_star2.setBackgroundColor(Color.parseColor("#FFFF80"));
            btn_star3.setBackgroundColor(Color.parseColor("#FFFF80"));
            btn_star4.setBackgroundColor(Color.parseColor("#FFFF80"));
            btn_star5.setBackgroundColor(Color.parseColor("#DCDCDC"));
            newMark = 4;
            flag1 = true;
            flag2 = true;
            flag3 = true;
            flag4 = false;
            flag5 = true;
        } else {
            btn_star1.setBackgroundColor(Color.parseColor("#DCDCDC"));
            btn_star2.setBackgroundColor(Color.parseColor("#DCDCDC"));
            btn_star3.setBackgroundColor(Color.parseColor("#DCDCDC"));
            btn_star4.setBackgroundColor(Color.parseColor("#DCDCDC"));
            newMark = 0;
            flag4 = true;
        }
    }
    public void S5(View view) {
        if (flag5) {
            btn_star1.setBackgroundColor(Color.parseColor("#FFFF80"));
            btn_star2.setBackgroundColor(Color.parseColor("#FFFF80"));
            btn_star3.setBackgroundColor(Color.parseColor("#FFFF80"));
            btn_star4.setBackgroundColor(Color.parseColor("#FFFF80"));
            btn_star5.setBackgroundColor(Color.parseColor("#FFFF80"));
            newMark = 5;
            flag1 = true;
            flag2 = true;
            flag3 = true;
            flag4 = true;
            flag5 = false;
        } else {
            btn_star1.setBackgroundColor(Color.parseColor("#DCDCDC"));
            btn_star2.setBackgroundColor(Color.parseColor("#DCDCDC"));
            btn_star3.setBackgroundColor(Color.parseColor("#DCDCDC"));
            btn_star4.setBackgroundColor(Color.parseColor("#DCDCDC"));
            btn_star5.setBackgroundColor(Color.parseColor("#DCDCDC"));
            newMark = 0;
            flag5 = true;
        }

    }
}

