package ru.ispu.roads.ViewModel;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import ru.ispu.roads.Model.User;
import ru.ispu.roads.R;


public class LoginActivity extends AppCompatActivity  {

    EditText loginBox;
    EditText passwordBox;
    Button logButton;
    String Log ="";
    String Pass ="";
    String Role = "";
    long Id = 0;

    User user;
    SQLiteDatabase db;
    Cursor userCursor;
    SimpleCursorAdapter userAdapter;
    long userId=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loginBox = (EditText) findViewById(R.id.login);
        passwordBox = (EditText) findViewById(R.id.password);
        logButton = (Button) findViewById(R.id.logButton);
    }

    public void log(View view){

            user = new User(this);
            db = user.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT  * FROM "+ User.TABLE_NAME, null);//" + User.TABLE_NAME + " WHERE KEY_LOGIN = " + loginBox.getText().toString(), null);
            String[] headers = new String[] {User.KEY_ID, User.KEY_LOGIN, User.KEY_PASSWORD, User.KEY_ROLE};
            cursor.moveToFirst();
            boolean checker = false;
            for (int i = 0; i < cursor.getCount(); i++){
                Id = cursor.getLong(0);
                Log = cursor.getString(1);
                Pass = cursor.getString(2);
                Role = cursor.getString(3);
                if (loginBox.getText().toString().equals(Log) & passwordBox.getText().toString().equals(Pass)) {
                    checker = true;
                    break;
                }
                cursor.moveToNext();
            }
            if (checker) {
                goHome();
            }
            else
            {
                Toast toast = Toast.makeText(this, "Неправильный логин или пароль.",Toast.LENGTH_LONG);
                toast.show();
            }
    }

    private void goHome(){
        // закрываем подключение
        db.close();
        // переход к главной activity
        Intent intent = new Intent(this, MainActivity.class);
        //intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra("userId", Id);
        intent.putExtra("login", loginBox.getText().toString());
        intent.putExtra("role", Role);
        startActivity(intent);
    }
}
