package ru.ispu.roads.ViewModel;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import ru.ispu.roads.Model.User;
import ru.ispu.roads.R;

public class RegisterActivity extends AppCompatActivity {

    EditText loginBox;
    EditText passwordBox;
    EditText password2Box;
    Button regButton;

    User user;
    SQLiteDatabase db;
    Cursor userCursor;
    long userId=0;
    String userLogin = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        loginBox = (EditText) findViewById(R.id.login);
        passwordBox = (EditText) findViewById(R.id.password);
        password2Box = (EditText) findViewById(R.id.password2);
        regButton = (Button) findViewById(R.id.regButton);

        user = new User(this);
        db = user.getWritableDatabase();

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            userId = extras.getLong("id");
        }
        // если 0, то добавление
        if (userId > 0) {
            // получаем элемент по id из бд
            userCursor = db.rawQuery("select * from " + User.TABLE_NAME + " where " +
                    User.KEY_ID + "=?", new String[]{String.valueOf(userId)});
            userCursor.moveToFirst();
            loginBox.setText(userCursor.getString(1));
            passwordBox.setText(userCursor.getString(2));
            password2Box.setText(userCursor.getString(3));
            userCursor.close();
        }
    }

    public void reg(View view){
        String s= "Пользователь";
        db.close();
        db = user.getReadableDatabase();
        userCursor = db.rawQuery("select * from " + User.TABLE_NAME + " where " +
                User.KEY_LOGIN + " =?", new String[]{loginBox.getText().toString()});
        if (userCursor.getCount() == 0) {
            db.close();
            db = user.getWritableDatabase();
            if (passwordBox.getText().toString().equals(password2Box.getText().toString())) {
                ContentValues cv = new ContentValues();
                cv.put(User.KEY_LOGIN, loginBox.getText().toString());
                cv.put(User.KEY_PASSWORD, passwordBox.getText().toString());
                cv.put(User.KEY_ROLE, s);


                if (userId > 0) {
                    db.update(User.TABLE_NAME, cv, User.KEY_ID + "=" + String.valueOf(userId), null);
                } else {
                    db.insert(User.TABLE_NAME, null, cv);
                }
                goHome();
            } else {
                Toast toast = Toast.makeText(this, "Проверьте подтверждение пароля", Toast.LENGTH_LONG);
                toast.show();
            }
        }
        else
        {
            Toast toast = Toast.makeText(this, "Такой логин уже существует", Toast.LENGTH_LONG);
            toast.show();
        }
    }

    private void goHome(){
        // закрываем подключение
        db.close();
        // переход к главной activity
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
    }
}
