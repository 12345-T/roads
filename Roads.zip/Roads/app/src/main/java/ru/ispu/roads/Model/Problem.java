package ru.ispu.roads.Model;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;
import android.util.Patterns;

public class Problem extends SQLiteOpenHelper {

    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "ProblemsDB";
    public static final String TABLE_NAME = "Problems";
    public static final String KEY_ID = "_id";
    public static final String KEY_NAME = "name";
    public static final String KEY_ADRESS = "adress";
    public static final String KEY_CATEGORY = "category";
    public static final String KEY_DESCRIPTION = "description";
    public static final String KEY_AVERAGE_MARK = "mark";
    public static final String KEY_NUMBER_OF_RATED_USERS = "number";
    public static final String KEY_USER_ID = "user_id";
    public Problem(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table "+ TABLE_NAME
                + "("+KEY_ID + " integer primary key, "
                + KEY_NAME + " text," + KEY_ADRESS + " text," + KEY_CATEGORY + " text,"
                + KEY_DESCRIPTION + " text," + KEY_AVERAGE_MARK + " text,"
                + KEY_NUMBER_OF_RATED_USERS + " text," + KEY_USER_ID + " text);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exist" + DATABASE_NAME);
        onCreate(db);
    }
}

