package ru.ispu.roads.Model;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ProblemUser extends SQLiteOpenHelper {

    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "Problems7DB";
    public static final String TABLE_NAME = "ProblemUsers";
    public static final String KEY_ID = "_id";
    public static final String KEY_USER_ID = "userId";
    public static final String KEY_PROBLEM_ID = "problemId";
    public static final String KEY_MARK = "mark";
    public ProblemUser(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table "+ TABLE_NAME
                + "("+KEY_ID + " integer primary key, "
                + KEY_USER_ID + " text," + KEY_PROBLEM_ID + " text,"
                + KEY_MARK + " text);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exist" + DATABASE_NAME);
        onCreate(db);
    }
}
