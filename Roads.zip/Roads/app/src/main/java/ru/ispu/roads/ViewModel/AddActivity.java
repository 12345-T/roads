package ru.ispu.roads.ViewModel;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import ru.ispu.roads.Model.Problem;
import ru.ispu.roads.R;

public class AddActivity extends AppCompatActivity {

    String[] categories = {"В ужасном состоянии", "В плохом состоянии", "Локальный дефект/ Яма", "Мелкий дефект"};
    EditText nameBox;
    EditText adressBox;
    Spinner categoryBox;
    EditText descriptionBox;
    Button delButton;
    Button saveButton;

    String Cat_name;
    Problem problem;
    SQLiteDatabase db;
    Cursor problemCursor;
    long problemId=0;
    long userId = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        nameBox = (EditText) findViewById(R.id.add_name);
        adressBox = (EditText) findViewById(R.id.add_adress);
        categoryBox = (Spinner) findViewById(R.id.add_category);
        descriptionBox = (EditText) findViewById(R.id.add_description);
        delButton = (Button) findViewById(R.id.deleteButton);
        saveButton = (Button) findViewById(R.id.saveButton);
        categoryBox.setPrompt("Выберите категорию");
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categoryBox.setAdapter(adapter);
        categoryBox.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // показываем позиция нажатого элемента
                //Toast.makeText(getBaseContext(), "Position = " + position, Toast.LENGTH_SHORT).show();
                Cat_name = categories[position];
            }
            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });


        problem = new Problem(this);
        db = problem.getWritableDatabase();

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            userId = extras.getLong("userId");
            //problemId = extras.getLong("id");
        }
        // если 0, то добавление
        /*if (problemId > 0) {
            // получаем элемент по id из бд
            problemCursor = db.rawQuery("select * from " + Problem.TABLE_NAME + " where " +
                    Problem.KEY_ID + "=?", new String[]{String.valueOf(problemId)});
            problemCursor.moveToFirst();
            nameBox.setText(problemCursor.getString(1));
            adressBox.setText(problemCursor.getString(2));
            //categoryBox.setText(problemCursor.getString(3));
            descriptionBox.setText(problemCursor.getString(4));
            problemCursor.close();
        } else {*/
            // скрываем кнопку удаления
            delButton.setVisibility(View.GONE);
        //}
    }

    public void save(View view){
        String Id = userId+"";
        ContentValues cv = new ContentValues();
        cv.put(Problem.KEY_NAME, nameBox.getText().toString());
        cv.put(Problem.KEY_ADRESS, adressBox.getText().toString());
        cv.put(Problem.KEY_CATEGORY, Cat_name);
        cv.put(Problem.KEY_DESCRIPTION, descriptionBox.getText().toString());
        cv.put(Problem.KEY_AVERAGE_MARK, "0");
        cv.put(Problem.KEY_NUMBER_OF_RATED_USERS, "0");
        cv.put(Problem.KEY_USER_ID, Id);

        if (problemId > 0) {
            db.update(Problem.TABLE_NAME, cv, Problem.KEY_ID + "=" + String.valueOf(problemId), null);
        } else {
            db.insert(Problem.TABLE_NAME, null, cv);
        }
        goHome();
    }
    public void delete(View view){
        db.delete(Problem.TABLE_NAME, "_id = ?", new String[]{String.valueOf(problemId)});
        goHome();
    }
    private void goHome(){
        // закрываем подключение
        db.close();
        // переход к главной activity
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
    }
}
