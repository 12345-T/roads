package ru.ispu.roads.ViewModel;


public class ProblemAdapter {//extends ArrayAdapter<User> {

   /* private LayoutInflater inflater;
    private int layout;
    private List<User> users;

    public ProblemAdapter(Context context, int resource, List<User> users) {
        super(context, resource, users);
        this.users = users;
        this.layout = resource;
        this.inflater = LayoutInflater.from(context);
    }
    public View getView(int position, View convertView, ViewGroup parent) {

        View view=inflater.inflate(this.layout, parent, false);

        TextView nameView = (TextView) view.findViewById(R.id.mail);
        TextView capitalView = (TextView) view.findViewById(R.id.password);

        User user = users.get(position);

        nameView.setText(user.getEmail());
        capitalView.setText(user.getPassword());

        return view;
    }*/
}