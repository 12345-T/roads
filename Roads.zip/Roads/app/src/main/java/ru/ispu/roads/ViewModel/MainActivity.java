package ru.ispu.roads.ViewModel;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import ru.ispu.roads.Model.Problem;
import ru.ispu.roads.R;


public class MainActivity extends AppCompatActivity{


    ListView problemList;
    Problem problem;
    SQLiteDatabase db;
    Cursor problemCursor;
    SimpleCursorAdapter problemAdapter;
    String LogName = "";
    String UserRole;
    Button btn_auth;
    Button btn_reg;
    TextView logBox;
    Button btn_exit;
    Bundle extras;
    long userId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent2 = getIntent();

        setContentView(R.layout.activity_main);

        problemList = (ListView)findViewById(R.id.plist);
        problemList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), ProblemActivity.class);
                intent.putExtra("id", id);
                startActivity(intent);
            }
        });

        problem = new Problem(getApplicationContext());
    }
    @Override
    public void onResume() {
        super.onResume();

        extras = getIntent().getExtras();
        if (extras != null) {
            LogName = extras.getString("login");
            UserRole = extras.getString("role");
            userId =  extras.getLong("userId");
            btn_auth = (Button) findViewById(R.id.btn_auth);
            btn_reg = (Button) findViewById(R.id.btn_reg);
            btn_auth.setVisibility(View.INVISIBLE);
            btn_auth.setVisibility(View.GONE);
            btn_reg.setVisibility(View.INVISIBLE);
            btn_reg.setVisibility(View.GONE);
            logBox = (TextView) findViewById(R.id.user_log);
            btn_exit = (Button) findViewById(R.id.exit);
            logBox.setVisibility(View.VISIBLE);
            logBox.setText(LogName);
            btn_exit.setVisibility(View.VISIBLE);
            problemList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent intent = new Intent(getApplicationContext(), ProblemActivity.class);
                    intent.putExtra("id", id);
                    intent.putExtra("login", LogName);
                    intent.putExtra("role", UserRole);
                    startActivity(intent);
                }
            });
        }
        // открываем подключение
        db = problem.getReadableDatabase();

        //получаем данные из бд в виде курсора
        problemCursor =  db.rawQuery("select * from "+ Problem.TABLE_NAME, null);
        // определяем, какие столбцы из курсора будут выводиться в ListView
        String[] headers = new String[] {Problem.KEY_NAME, Problem.KEY_ADRESS, Problem.KEY_CATEGORY, Problem.KEY_AVERAGE_MARK}; //, Trainer.COLUMN_PASSWORD, Trainer.COLUMN_REGISTRATION_DATE, Trainer.COLUMN_CURRENT_THEME
        // создаем адаптер, передаем в него курсор
        problemAdapter = new SimpleCursorAdapter(this, android.R.layout.simple_expandable_list_item_2,
                problemCursor, headers, new int[]{android.R.id.text1, android.R.id.text2}, 0);
        problemList.setAdapter(problemAdapter);
    }
    // по нажатию на кнопку запускаем AddActivity для добавления данных
    public void add(View view){
        Intent intent = new Intent(this, AddActivity.class);
        intent.putExtra("userId", userId);
        startActivity(intent);
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        // Закрываем подключение и курсор
        db.close();
        problemCursor.close();
    }



    public void sendMessage2(View view) {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }
    public void sendMessage3(View view) {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }
    public void exit(View view) {
        LogName = "";
        btn_auth = (Button) findViewById(R.id.btn_auth);
        btn_reg = (Button) findViewById(R.id.btn_reg);
        logBox = (TextView) findViewById(R.id.user_log);
        btn_exit = (Button) findViewById(R.id.exit);
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}
